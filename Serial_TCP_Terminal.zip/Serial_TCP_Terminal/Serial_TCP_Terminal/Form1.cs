﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO.Ports;
using System.Text.RegularExpressions;


namespace Serial_TCP_Terminal
{
    public partial class Form1 : Form
    {
        public delegate void Displaydelegate(byte[] InputBuf);
        public Displaydelegate disp_delegate;
        public void DispUI(byte[] InputBuf)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            textReceive.AppendText(encoding.GetString(InputBuf));
        }

        public Form1()
        {
            disp_delegate = new Displaydelegate(DispUI);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Get all ports
            string[] ports = SerialPort.GetPortNames();
            comboxBox1.Items.AddRange(ports);
            comboxBox1.SelectedIndex = 0;
            BtnClose.Enabled = false;
        }

// Open Button
        private void BtnOpen_Click(object sender, EventArgs e)
        {
            BtnOpen.Enabled = false;
            BtnClose.Enabled = true;
            try
            {
                serialPort1.PortName = comboxBox1.Text;
                serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text, 10);
                serialPort1.Open();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

// Close Button
        private void BtnClose_Click(object sender, EventArgs e)
        {
            BtnOpen.Enabled = true;
            BtnClose.Enabled = false;
            textSend.Clear();
            textReceive.Clear();
            try
            {
                serialPort1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

// Send Button
        private void BtnSend_Click(object sender, EventArgs e)
        {
            try
            {
                if(!serialPort1.IsOpen)
                {
                    MessageBox.Show("Serial port is not open", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    serialPort1.Close();
                    BtnOpen.Enabled = true;
                    BtnClose.Enabled = false;
                }
                else
                {
                    serialPort1.WriteLine(textSend.Text + Environment.NewLine);
                    textSend.Clear();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

// Recive Button
        private void BtnReceive_Click(object sender, EventArgs e)
        {
            try
            {
                if (!serialPort1.IsOpen)
                {
                    MessageBox.Show("Serial port is not open", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    serialPort1.Close();
                }
                else {
                    // Read text from port
                    textReceive.Text = serialPort1.ReadExisting() + Environment.NewLine;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

// Form Close
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
                serialPort1.Close();
        }

        private void SerialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int n = serialPort1.BytesToRead;
            Byte[] InputBuf = new byte[n];
            try
            {
                serialPort1.Read(InputBuf, 0, n);
                this.Invoke(disp_delegate, InputBuf);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
